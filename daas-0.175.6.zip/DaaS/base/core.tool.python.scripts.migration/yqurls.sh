if [ "$#" -ne 1 ]; then
  echo "No yml file for yq!"
  exit 1
fi

urls=$(yq r deploy.yml deployment.scripts.urls | awk '{print $2}')
tag=$(yq r deploy.yml deployment.scripts.tool.tag)

urlstr=""
for i in $urls
do
  urlstr+=$i','
done

urlstr=${urlstr%?}

printf "Injecting \n-------\n$urls \n-------\ninto $1's environment variable PN_GLOBAL_SCRIPT_URLS\n"

image="cr.pentium.network/deploy-scripts:$tag"
yq w $1 spec.template.spec.containers[0].env[0].value $urlstr > tmp.yml
yq w tmp.yml spec.template.spec.containers[0].image $image > tmp2.yml
mv tmp2.yml deploy-scripts-job.yml
# sleep 1
rm tmp.yml