if [ "$#" -ne 1 ]; then
  echo "No tag input for sed!"
  exit 1
fi

echo $1

find k8s-deploy-scripts.yml | xargs grep '{{tag}}' -sl | while read file
do
sed 's/{{tag}}/'"$1"'/g' "$file" > tmpfile
mv tmpfile "$file"
done
