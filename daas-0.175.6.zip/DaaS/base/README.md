# base pool of deploy yamls for Pentium.Network
