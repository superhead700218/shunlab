# fluentd for GDE
本版只適用於 gde 環境

## 說明

請參考`k8s-fluentd-collector-daemonset.yaml`
**修改 log path 會對所有 namespace 生效**

### 增刪修 namespace
```
- name: FLUENTD_ALL_NAMESPACE
  value: "corezilla platform-workflow-preview qa-cicd workflow-preview workflow-stable"
```

### 增刪修 log path
```
- name: FLUENTD_CONTAINERS_LOG_PATH
  value: /var/log/containers/*_$(POD_NAMESPACE)-router-*.log,/var/log/containers/*$(POD_NAMESPACE)-openfaas-fn*.log,/var/log/containers/ofsm-runner-*_$(POD_NAMESPACE)_*.log,/var/log/containers/scripts-runner-*_$(POD_NAMESPACE)_*.log,/var/log/containers/scripts-service-*_$(POD_NAMESPACE)_*.log,/var/log/containers/workflows-eventhandler-*_$(POD_NAMESPACE)_*.log,/var/log/containers/scripts-installer-*_$(POD_NAMESPACE)_*.log,/var/log/containers/cloudkit-*_$(POD_NAMESPACE)_*.log,/var/log/containers/rbac-condition-constructor-*_$(POD_NAMESPACE)_*.log,/var/log/containers/cloudvm-manipulator-*_$(POD_NAMESPACE)_*.log,/var/log/containers/gateone-*_$(POD_NAMESPACE)_*.log,/var/log/containers/sftp-*_$(POD_NAMESPACE)_*.log,/var/log/containers/workflows-templateinstaller-*_$(POD_NAMESPACE)_*.log
```

## build & apply
```
kustomize build | kubectl apply -f -
```
