# 這版目前暫不使用!!

### 說明
  - 這個 fluent-bit 只作為 gde 環境部署, 用來取代原本 fluentd 的 daemonset
  - gde 環境全部只需要部署一份 fluent-bit 做 log collector
  - fluent-bit 以 daemonset 方式部署到各個 node
  - fluent-bit 蒐集 /var/log/containers 的資料後 forward 對應 ns 底下的 fluentd
  - 需修改 output_forward.conf 的設定才會生效
  - fluent-bit 需設定 RBAC 權限 (ClusterRole, ClusterRoleBinding, ServiceAccount)
  - 各 ns 原本的 fluentd daemonset 不再自己蒐集log, 將移除 daemonset, 改裝 fluentd deployment
