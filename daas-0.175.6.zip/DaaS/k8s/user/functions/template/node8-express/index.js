// Copyright (c) Alex Ellis 2017. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

'use strict'

const express = require('express')
const app = express()
const handler = require('./function/handler')
const bodyParser = require('body-parser')

// app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json())
app.use(bodyParser.raw())
app.use(bodyParser.text({ type : 'text/*' }))
app.disable('x-powered-by')

class FunctionEvent {
  constructor (req) {
    this.body = req.body
    this.headers = req.headers
    this.method = req.method
    this.query = req.query
    this.path = req.path
  }
}

class FunctionContext {
  constructor (cb) {
    this.value = 200
    this.cb = cb
    this.headerValues = {}
  }

  status (value) {
    if(!value) {
      return this.value
    }

    this.value = value
    return this
  }

  headers (value) {
    if(!value) {
      return this.headerValues
    }

    this.headerValues = value
    return this    
  }

  succeed (value) {
    let err
    this.cb(err, value)
  }

  fail (value) {
    let message
    this.cb(value, message)
  }
}

const middleware = (req, res) => {
  const cb = (err, functionResult) => {
    if (err) {
      console.error(err)
      return res.status(500).send(err)
    }

    if(isArray(functionResult) || isObject(functionResult)) {
      res.send(JSON.stringify(functionResult))
    } else {
      res.set(fnContext.headers()).status(fnContext.status()).send(functionResult)
    }
  }

  const fnEvent = new FunctionEvent(req)
  const fnContext = new FunctionContext(cb)
  
  if(!isObject(fnEvent.body)) {
    fnEvent.body = JSON.parse(fnEvent.body)
  } 
  handler.handler(fnEvent.body, fnContext, cb)
}

app.post('/*', middleware)
app.get('/*', middleware)

const port = process.env.http_port || 3000

app.listen(port, () => {
  console.log(`OpenFaaS Node.js listening on port: ${port}`)
})

const isArray = (a) => {
  return !!a && a.constructor === Array
}

const isObject = (a) => {
  return !!a && a.constructor === Object
}
