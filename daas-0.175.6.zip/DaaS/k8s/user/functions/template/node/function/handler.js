'use strict'

module.exports.handler = (event, callback) => {
  callback(null, {state: 'done'})
}