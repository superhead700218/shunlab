// Copyright (c) Alex Ellis 2017. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

'use strict'

const getStdin = require('get-stdin')

const handler = require('./function/handler')

getStdin().then(val => {
  // val string
  if (!isObject(val)) {
    val = JSON.parse(val)
  }
  const context = {callbackWaitsForEmptyEventLoop: null}
  handler.handler(val, context, (err, res) => {
    if (err) {
      return console.error(err)
    }
    if (isArray(res) || isObject(res)) {
      process.stdout.write(JSON.stringify(res))
    } else {
      process.stdout.write(res)
    }
  })
}).catch(e => {
  console.error(e.stack)
})

const isArray = (a) => {
  return (!!a) && (a.constructor === Array)
}

const isObject = (a) => {
  return (!!a) && (a.constructor === Object)
}
