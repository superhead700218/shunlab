{
  'host': 'bolt://192.168.101.105:7687', // 'bolt://52.73.83.101:7687',
  'user': 'neo4j',
  'password': 'pnetwork',
  'hashkey': '2E4ihRGfv3ljiIRjf5',
  'hashlen': 6,
  'adminRoleId': 12000,
  'url': 'http://192.168.89.87:30001/', // front-end  'https://portal-dev.pentium.network/',
  'ansibleHost': 'http://192.168.89.87:30004', // 'http://192.168.89.52', // 'https://ansibleapi-dev.pentium.network',
  'authApi': 'http://192.168.89.87:30001/api/auth', //
  'dbAndAliApi': 'http://192.168.89.87:30002/', // DB API same url
  'SEARCH_IMAGE': 'https://ecs-buy.aliyun.com/api/ecsImage/describeImages.json', //
  'INSTANCE_LIST': 'https://ecs-buy.aliyun.com/api/v2/instance/instanceType/describeAvailableInstanceTypes.json', //
  'INSTANCE_DETAIL': 'https://ecs-buy.aliyun.com/api/v2/instance/instanceType/describeInstanceTypes.json?',
  'OPENFAAS_URL': '192.168.89.87:31112', // deploy openfaas
  'OPENFAAS_DOCKER_HUB': '211.75.237.243:46004/' // push docker registry
}