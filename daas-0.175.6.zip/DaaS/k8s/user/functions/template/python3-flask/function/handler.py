def faasHandler(event, context):
    """handle a request to the function
    Args:
        event (json dumps str): request body
    """

    return event
